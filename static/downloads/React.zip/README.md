# Movies Entertainment Web App 🎬

CHẠY PROJECT : 

#1 chạy lên để install các thư viện cần có : npm install  
#2 lệnh để chạy dự án : npm start  